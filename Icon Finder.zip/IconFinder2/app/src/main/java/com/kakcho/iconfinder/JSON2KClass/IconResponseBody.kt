package com.kakcho.iconfinder.JSON2KClass

import com.google.gson.annotations.SerializedName
//import com.kakcho.iconfinder.Pojo.Icon
import com.kakcho.iconfinder.JSON2KClass.Icon
import java.util.*

class IconResponseBody {
    @SerializedName("icons")
    var icons: ArrayList<Icon>? = null

    @SerializedName("total_count")
    var total_count: String? = null

    @SerializedName("message")
    var message: String? = null

    @SerializedName("code")
    var code = 0
}