package com.kakcho.iconfinder.JSON2KClass


import com.google.gson.annotations.SerializedName

class Style{
    @SerializedName("identifier")
    var identifier: String? = null // glyph
    @SerializedName("name")
    var name: String? = null // Glyph
}