package com.kakcho.iconfinder.Rest

class ApiCredential {

        //   public static final String apiClientId="7b2K2UDSoiAo7m2ZQmwK9BnYWcDkIjkZsEmDigifUAr7FZ93LTR9jgcmD5lCPfyH";
        val apiClientId = "V0TvTIwhJnKM9BxpClG5cWbZETAvAwkH8Ck5gMktny1BnCS8ywlopXLDt7Gvb1FS"

        //   public static final String apiClientSecret="44nLnLBk9SZy97MS2M0e1LR6X5fauv9atMtTfad7tarKowWaRbJhe5Hd2KpwBtRw";
        val apiClientSecret = "fNPwUHulbzmqrzhXkbttzUqOkqr3QxQlWD18Cu97ilOLU5zB1xD2jA1YC6QKd3x1"
        val baseUrl = "https://api.iconfinder.com/"


}