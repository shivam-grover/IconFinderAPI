package com.kakcho.iconfinder.Rest

interface ResponseCallback<T> {
    fun success(t: T)
    fun failure(t: T)
}